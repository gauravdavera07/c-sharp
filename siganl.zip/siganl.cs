﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace signal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int i = 0;
       
     
        private void timer2_Tick(object sender, EventArgs e)
        {
            i++;
            if (i <= 5)
            {
                button1.Visible = true;
                button2.Visible = false;
                button3.Visible = false;
            }
            else if (i <= 10)
            {
                button1.Visible = false;
                button2.Visible = true;
                button3.Visible = false;

            }
            else if (i <= 15)
            {
                button1.Visible = false;
                button2.Visible = false;
                button3.Visible = true;
                if (i == 15)
                {
                    i = 0;
                }
            }
        }
    }
}
